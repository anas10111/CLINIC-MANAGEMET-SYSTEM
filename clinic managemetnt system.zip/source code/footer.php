
            <footer class="footer text-center" ><marquee behavior="alternate">© 2020 All Rights are Reserved <a href="nikhilbhalerao.com"  target="_blank" style="color: yellow;"><?php echo "Developed by Freelancer Nikhil Bhalerao : +91 9423979339 ";?>
           
</a></marquee></footer> 

            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->  
    </div>
  


<script type="text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script>

    <script type="text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script>




<script src="files/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>



<script src="files/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="files/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="files/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<script src="files/assets/pages/data-table/js/data-table-custom.js"></script>


<script src="files/assets/js/pcoded.min.js"></script>

<script src="files/assets/js/vartical-layout.min.js"></script>
<script src="files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="files/assets/js/jquery.mousewheel.min.js"></script>

<script type="text/javascript" src="files/assets/js/script.min.js"></script>
<script type="text/javascript" src="files/assets/js/script.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.0.4/popper.js"></script>


</body>


</html>
